// Does the Lab actually show the working — including the failures?
//
// ---------------------------------------------------------------------------
// The point of the Lab is that a claim about the detector's residue can be
// checked rather than taken on trust. So this check is not "does it render": it
// steps through a puzzle it solves and one it FAILS, reads the tables off the
// page, and asserts the things that would make the screen dishonest —
//   * a failed puzzle whose ranking table omits the move that was actually
//     played (a table that hides the right answer is worse than no table),
//   * a bare coordinate pair anywhere on the page (moves carry a glyph),
//   * a ply that takes so long to annotate the tab reads as broken.
//
// Run: node scripts/lab-check.mjs   (needs a built dist)
// ---------------------------------------------------------------------------

import { chromium } from 'playwright';
import { spawn } from 'node:child_process';

const srv = spawn('node', ['node_modules/vite/bin/vite.js', 'preview', '--port', '4327', '--strictPort'], {
	stdio: 'ignore',
});
await new Promise((r) => setTimeout(r, 2500));
const b = await chromium.launch({ executablePath: process.env.PLAYWRIGHT_CHROMIUM });

const fail = [];
const p = await b.newPage({ viewport: { width: 1280, height: 1100 } });
p.on('console', (m) => {
	if (m.type() === 'error' && !/ERR_TUNNEL/.test(m.text())) fail.push(`console: ${m.text()}`);
});
await p.goto('http://localhost:4327/', { waitUntil: 'networkidle' });
await p.getByRole('button', { name: 'Lab', exact: true }).click();
await p.waitForTimeout(500);

const counts = await p.evaluate(() => document.body.innerText.match(/\d+ in this filter[^\n]*/)?.[0] ?? '');
console.log('filter line:', counts);
if (!/\d+ in this filter/.test(counts)) fail.push('no filter summary rendered');

/** Read the current ply: verdict text and the ranking table. */
const read = () =>
	p.evaluate(() => {
		const table = document.querySelector('table');
		const wrap = document.querySelector('.cg-wrap');
		return {
			body: document.body.innerText,
			table: table ? table.innerText.replace(/\n/g, ' | ') : null,
			orientation: wrap?.classList.contains('orientation-black') ? 'black' : 'white',
			// Arrow colours, so the check can tell which move is being drawn loudest.
			shapes: document.querySelector('.cg-shapes')?.innerHTML ?? '',
			// chessground's board is the custom element <cg-board>, not a .cg-board
			// class — a selector that reads right and matches nothing.
			lastMove: document.querySelectorAll('square.last-move').length,
		};
	});

/** Click through every ply chip, timing each. */
async function walk(label) {
	// The solution list IS the navigation, so the plies are addressed by index
	// rather than by their text — the text is a move, and moves repeat.
	const chips = await p.evaluate(() =>
		[...document.querySelectorAll('button[data-ply]')].map((b) => b.getAttribute('data-ply')),
	);
	console.log(`\n=== ${label} — ${chips.length} plies: ${chips.join(' ')}`);
	const verdicts = [];
	const orientations = [];
	for (const c of chips) {
		const t0 = Date.now();
		await p.locator(`button[data-ply="${c}"]`).click();
		// The ply is scored after a paint, so the check waits for the result rather
		// than for a fixed interval — the fixed interval was how a two-second hang
		// went unnoticed.
		if (c !== '0') {
			// The table carries the ply it was computed for, so this cannot latch
			// onto the PREVIOUS ply's ranking still on screen — which is exactly the
			// stale frame this check caught the first time it ran.
			await p
				.locator(`table[data-ply-detail="${c}"]`)
				.waitFor({ state: 'visible', timeout: 8000 })
				.catch(() => fail.push(`${label} ply ${c}: no ranking within 8s`));
		}
		const ms = Date.now() - t0;
		const { body, table, orientation, lastMove, shapes } = await read();
		orientations.push(orientation);
		// Every ply after the first must show what was just played, or the board
		// changes without saying why.
		if (c !== '0' && lastMove < 2) fail.push(`${label} ply ${c}: no last-move highlight`);
		const verdict = /Found it|No opinion|Missed it|Not counted/.exec(body)?.[0] ?? 'blunder';
		verdicts.push(verdict);
		console.log(`  ply ${c.padEnd(8)} ${String(ms).padStart(5)}ms  ${verdict}`);
		if (table) console.log(`      ${table}`);

		// The puzzle's move must appear in the ranking, hit or miss.
		if (verdict !== 'blunder' && table && !/the puzzle's move/.test(table)) {
			fail.push(`${label} ply ${c}: ranking omits the puzzle's move`);
		}
		// Changing ply must not lock the tab up. One ply is about 200ms; a whole
		// chain at once used to be seconds, which is the bug this guards.
		// A guard against the tab appearing frozen, not a performance target: the
		// threat extension and the mate scan both make some positions genuinely
		// slower, and that is a trade already measured and accepted.
		if (ms > 3500) fail.push(`${label} ply ${c}: ${ms}ms to annotate`);

		// The puzzle's move is the answer and must be the loudest thing on the
		// board; the detector's mistaken choice must be RED. It used to be drawn in
		// the heaviest green on the quality ramp — louder than the right move, and
		// saying "best" about it into the bargain.
		if (verdict !== 'blunder') {
			if (!/#0b6b3a/.test(shapes)) fail.push(`${label} ply ${c}: the puzzle's move is not the strong arrow`);
			if (verdict === 'Missed it' && !/#882020/.test(shapes)) {
				fail.push(`${label} ply ${c}: a missed ply drew no red arrow`);
			}
		}
	}
	// No bare coordinate pairs: every move carries a piece glyph.
	const { body } = await read();
	const bare = body.match(/(^|[\s—(])[a-h][1-8][–x×-][a-h][1-8]/g);
	if (bare) fail.push(`${label}: bare coordinate moves ${JSON.stringify(bare.slice(0, 3))}`);

	// A puzzle is one side's problem throughout. The board must not spin.
	if (new Set(orientations).size !== 1) {
		fail.push(`${label}: board rotated mid-chain ${JSON.stringify(orientations)}`);
	}
	// And it must be the solver's side — the one answering the blunder.
	const solverIs = /(White|Black) to move — this is the solver/.exec(body);
	if (solverIs && orientations[0] !== solverIs[1].toLowerCase()) {
		fail.push(`${label}: solver is ${solverIs[1]} but board shows ${orientations[0]}`);
	}
	console.log(`  orientation: ${orientations[0]}`);
	return verdicts;
}

/**
 * Change the filter, and time it.
 *
 * Will: "when I change the Show selector option, the page hangs." It did — the
 * whole chain was scored synchronously on selection, which on a twelve-ply
 * puzzle is seconds of frozen main thread. The fix is to score one ply on
 * demand, and this is the assertion that keeps it fixed.
 */
async function choose(value) {
	const t0 = Date.now();
	await p.selectOption('select >> nth=1', value);
	await p.locator('button[data-ply="0"]').waitFor({ state: 'visible', timeout: 8000 });
	const ms = Date.now() - t0;
	console.log(`\nfilter -> ${value}: ${ms}ms`);
	if (ms > 1500) fail.push(`switching the filter to ${value} took ${ms}ms`);
	return !(await p.evaluate(() => /Nothing matches/.test(document.body.innerText)));
}

// One it solves.
await choose('sharp');
const sharpV = await walk('sharp');
// That is what "sharp" means: no ply passed only by a tie, and none was missed.
if (sharpV.some((v) => v === 'No opinion' || v === 'Missed it')) {
	fail.push(`a "sharp" puzzle contained ${JSON.stringify(sharpV)}`);
}

// One that passes only by a tie: the honest middle case must be reachable.
if (!(await choose('tied'))) fail.push('no tie-only puzzles browsable');
else await walk('tied');

// One it fails — the reason this screen exists.
if (!(await choose('failed'))) fail.push('no failing puzzles browsable');
else await walk('failed');

// The argument: the chain's structure, not just its number. This is the thing
// the whole coercion search exists to produce, so the check makes sure it is on
// the screen and says something about what the opponent still has.
{
	const arg = await p
		.locator('text=/Why .*: every reply that holds/')
		.first()
		.waitFor({ state: 'visible', timeout: 12000 })
		.then(() => true)
		.catch(() => false);
	if (!arg) fail.push('no argument shown for the puzzle move');
	else {
		const body = await p.evaluate(() => document.body.innerText);
		const said = /replies hold|only legal move|only reply that holds/.test(body);
		if (!said) fail.push('the argument names no constraint on the opponent');
		const line = /Why[^\n]*\n([^\n]*)/.exec(body);
		console.log(`\nargument first line: ${line ? line[1] : '(none)'}`);
	}
}

// The Stockfish column: asked for, labelled, and belonging to this ply.
//
// It is the one place on the screen where an outside authority's numbers appear,
// so the check makes sure they arrive under their own heading rather than
// blending into the detector's.
{
	await p.locator('input[type="checkbox"]').check();
	const header = await p
		.locator('th', { hasText: 'Stockfish' })
		.waitFor({ state: 'visible', timeout: 5000 })
		.then(() => true)
		.catch(() => false);
	if (!header) fail.push('the Stockfish column did not appear when asked for');
	else {
		// The engine runs in a worker; give it room, and report rather than fail if
		// this environment cannot start it.
		const filled = await p
			.waitForFunction(
				() => {
					const t = document.querySelector('table');
					return !!t && !/…/.test(t.innerText);
				},
				{ timeout: 20000 },
			)
			.then(() => true)
			.catch(() => false);
		const row = await p.evaluate(() => document.querySelector('table')?.innerText.split('\n')[2] ?? '');
		console.log(`\nengine column ${filled ? 'filled' : 'STILL EMPTY'}: ${row.replace(/\t/g, ' | ')}`);
		if (!filled) console.log('  (engine may be unavailable in this environment — not treated as a failure)');
	}
	await p.locator('input[type="checkbox"]').uncheck();
}

// Play from here: the board must accept a move that is not the puzzle's.
{
	await p.locator('button[title*="Play on"]').click();
	const before = await p.evaluate(() => document.querySelectorAll('piece').length);
	// Drag the first legal-looking piece is fragile; instead check the mode is on
	// and that the annotation still says it belongs to the puzzle position.
	const note = await p.evaluate(() => /Playing on/.test(document.body.innerText));
	if (!note) fail.push('play-from-here did not turn on');
	if (!before) fail.push('board lost its pieces in play mode');
	await p.locator('button[title*="Stop playing"]').click();
}

// And the shuffle keeps working.
await p.getByRole('button', { name: 'Another position' }).click();
await p.waitForTimeout(800);
const after = await p.evaluate(() => document.querySelector('h3')?.innerText ?? '');
console.log('\nafter shuffle:', after.replace(/\n/g, ' '));
if (!after) fail.push('shuffle produced an empty position');

await b.close();
srv.kill();

console.log('\n' + (fail.length ? `FAIL\n  ${fail.join('\n  ')}` : 'OK'));
process.exit(fail.length ? 1 : 0);
