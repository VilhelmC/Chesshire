// For each failure: which intervention actually fixes it?
//
// ---------------------------------------------------------------------------
// `why.mjs` reported which feature was PRESENT when a move was missed. That is
// correlation, and it misled: 27% of failures had the engine's reply outside my
// pruned move list, and switching the pruning off entirely changed the score by
// nothing at all. The feature was there; it was not the cause.
//
// A cause is something that, when removed, fixes the answer. So each failure is
// re-run under one intervention at a time, and the report says which one flips
// it. Anything nothing flips is a genuine hole in the evaluation, and that
// residue is the only number here worth acting on.
//
// Usage: node scripts/ablate.mjs [puzzles] [depth] [solver|opponent|both]
// ---------------------------------------------------------------------------

import { readFileSync, writeFileSync, mkdtempSync, existsSync } from 'node:fs';
import { spawn } from 'node:child_process';
import { build } from 'esbuild';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const LIMIT = Number(process.argv[2] ?? 40);
const DEPTH = Number(process.argv[3] ?? 5);
const ROLE = process.argv[4] ?? 'both';
const ENGINE = ['/usr/games/stockfish', '/usr/bin/stockfish'].find((p) => existsSync(p));

const dir = mkdtempSync(join(tmpdir(), 'abl-'));
const entry = join(dir, 'entry.ts');
writeFileSync(
	entry,
	`export { scoreMoves } from ${JSON.stringify(join(process.cwd(), 'src/domain/resolve.ts'))};
	 export { positionFromFen, parseSquare, makeSquare } from ${JSON.stringify(join(process.cwd(), 'src/domain/chess.ts'))};`,
);
const outfile = join(dir, 'bundle.mjs');
await build({ entryPoints: [entry], bundle: true, format: 'esm', outfile, platform: 'node', logLevel: 'silent' });
const { scoreMoves, positionFromFen, parseSquare, makeSquare } = await import(outfile);

const LETTER = { pawn: 'p', knight: 'n', bishop: 'b', rook: 'r', queen: 'q', king: 'k' };
function fenOf(pos) {
	const rows = [];
	for (let r = 7; r >= 0; r--) {
		let row = '';
		let gap = 0;
		for (let f = 0; f < 8; f++) {
			const piece = pos.board.get(r * 8 + f);
			if (!piece) {
				gap++;
				continue;
			}
			if (gap) row += gap;
			gap = 0;
			const ch = LETTER[piece.role];
			row += piece.color === 'white' ? ch.toUpperCase() : ch;
		}
		if (gap) row += gap;
		rows.push(row);
	}
	return `${rows.join('/')} ${pos.turn === 'white' ? 'w' : 'b'} - - 0 1`;
}

const uci = (m) =>
	`${makeSquare(m.from)}${makeSquare(m.to)}${m.promotion ? (m.promotion[0] === 'k' ? 'n' : m.promotion[0]) : ''}`;
const toMove = (u) => {
	const from = parseSquare(u.slice(0, 2));
	const to = parseSquare(u.slice(2, 4));
	const promo = u[4] ? { q: 'queen', r: 'rook', b: 'bishop', n: 'knight' }[u[4]] : undefined;
	return promo ? { from, to, promotion: promo } : { from, to };
};
const play = (pos, u) => {
	const n = pos.clone();
	n.play(toMove(u));
	return n;
};

function evalMove(fen, mv, depth = 12) {
	if (!ENGINE) return Promise.resolve(null);
	return new Promise((resolve) => {
		const proc = spawn(ENGINE);
		let out = '';
		const timer = setTimeout(() => {
			proc.kill();
			resolve(null);
		}, 15_000);
		proc.stdout.on('data', (c) => {
			out += c.toString();
			if (!out.includes('bestmove')) return;
			clearTimeout(timer);
			proc.kill();
			let cp = null;
			for (const l of out.split('\n')) {
				const m = /score (cp|mate) (-?\d+)/.exec(l);
				if (m) cp = m[1] === 'mate' ? (Number(m[2]) > 0 ? 10000 : -10000) : Number(m[2]);
			}
			resolve(cp);
		});
		proc.stdin.write(`uci\nisready\nposition fen ${fen}\ngo depth ${depth} searchmoves ${mv}\n`);
	});
}

/** Is the played move among the best-scoring at these settings? */
function hits(pos, played, depth, opts) {
	const { scored } = scoreMoves(pos, depth, undefined, undefined, opts);
	if (!scored.length) return false;
	const top = scored[0].score;
	return scored.some((s) => s.score === top && uci(s.move) === played);
}

const INTERVENTIONS = [
	['depth +2', (pos, played) => hits(pos, played, DEPTH + 2, {})],
	['depth +4', (pos, played) => hits(pos, played, DEPTH + 4, {})],
	['no pruning', (pos, played) => hits(pos, played, DEPTH, { noPrune: true })],
	['no transposition table', (pos, played) => hits(pos, played, DEPTH, { noTT: true })],
	['no TT and no pruning', (pos, played) => hits(pos, played, DEPTH, { noTT: true, noPrune: true })],
];

const rows = readFileSync('data/puzzle_sample.csv', 'utf8').trim().split('\n');
const fixed = new Map();
let puzzles = 0;
let checked = 0;
let misses = 0;
let unexplained = 0;
const stubborn = [];

for (const line of rows) {
	if (puzzles >= LIMIT) break;
	const csv = line.split('|').slice(2).join('|').split(',');
	const [, fen, movesStr, , , , , themes] = csv;
	const mv = movesStr.split(' ');
	if (mv.length < 2) continue;

	let pos;
	try {
		pos = positionFromFen(fen);
	} catch {
		continue;
	}
	const at = [];
	let ok = true;
	for (const u of mv) {
		at.push(pos);
		try {
			pos = play(pos, u);
		} catch {
			ok = false;
			break;
		}
	}
	if (!ok) continue;
	puzzles++;

	for (let i = 1; i < mv.length; i++) {
		const role = i % 2 === 1 ? 'solver' : 'opponent';
		if (ROLE !== 'both' && ROLE !== role) continue;
		checked++;
		if (hits(at[i], mv[i], DEPTH, {})) continue;

		// Adjudicate: only a genuine difference counts as a failure.
		const posFen = fenOf(at[i]);
		const { scored } = scoreMoves(at[i], DEPTH);
		const A = await evalMove(posFen, mv[i]);
		const B = await evalMove(posFen, uci(scored[0].move));
		if (A === null || B === null || A - B <= 50) continue;
		misses++;

		let cause = null;
		for (const [name, run] of INTERVENTIONS) {
			let flipped = false;
			try {
				flipped = run(at[i], mv[i]);
			} catch {
				flipped = false;
			}
			if (flipped) {
				cause = name;
				break;
			}
		}
		if (cause) fixed.set(cause, (fixed.get(cause) ?? 0) + 1);
		else {
			unexplained++;
			if (stubborn.length < 10) {
				stubborn.push({
					posFen,
					role,
					played: mv[i],
					mine: uci(scored[0].move),
					myScores: `${scored.find((s) => uci(s.move) === mv[i])?.score ?? 'n/a'} vs ${scored[0].score}`,
					engine: `${A} vs ${B}`,
					line: (scored[0].line ?? []).map(uci).join(' '),
					themes,
				});
			}
		}
	}
}

console.log(`\nplies checked ${checked}, real misses ${misses}\n`);
console.log('-- what actually FIXES each failure --');
for (const [k, v] of [...fixed].sort((a, b) => b[1] - a[1])) {
	console.log(`  ${String(v).padStart(3)}  (${((v / misses) * 100).toFixed(0)}%)  ${k}`);
}
console.log(`  ${String(unexplained).padStart(3)}  (${((unexplained / misses) * 100).toFixed(0)}%)  NOTHING — a real hole in the evaluation`);

console.log('\n-- the stubborn ones --');
for (const s of stubborn) {
	console.log(`  ${s.posFen}   [${s.role}, ${s.themes}]`);
	console.log(`    played ${s.played}, I chose ${s.mine}   mine: ${s.myScores}   engine: ${s.engine}`);
	console.log(`    my line: ${s.line}`);
}
