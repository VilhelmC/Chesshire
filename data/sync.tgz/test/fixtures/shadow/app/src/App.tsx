// the shadow
