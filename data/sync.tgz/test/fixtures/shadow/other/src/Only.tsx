// no counterpart
